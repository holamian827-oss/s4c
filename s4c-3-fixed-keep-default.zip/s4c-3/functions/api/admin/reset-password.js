async function hashPassword(password, salt) {
    const msgBuffer = new TextEncoder().encode(password + salt);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    return Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, '0')).join('');
}

function getSessionToken(request) {
    const cookie = request.headers.get('Cookie') || '';
    const match = cookie.match(/(?:^|;\s*)session_token=([^;]+)/);
    return match ? decodeURIComponent(match[1]) : null;
}

async function requireAdmin(request, env, middlewareUser) {
    // Defense in depth: trust middleware when present, but re-check here so this
    // privileged endpoint stays protected even if routing/middleware changes.
    if (middlewareUser?.role === 'admin') return middlewareUser;

    const token = getSessionToken(request);
    if (!token) return null;

    const user = await env.DB.prepare(
        "SELECT username, role, banned_until, token_created_at FROM users WHERE session_token = ?"
    ).bind(token).first();

    if (!user || user.role !== 'admin' || !user.token_created_at) return null;

    const tokenAgeMs = Date.now() - new Date(user.token_created_at).getTime();
    if (!Number.isFinite(tokenAgeMs) || tokenAgeMs > 24 * 60 * 60 * 1000) return null;

    if (user.banned_until && (user.banned_until === 'permanent' || new Date(user.banned_until) > new Date())) {
        return null;
    }

    return user;
}

export async function onRequestPost({ request, data, env }) {
    try {
        const admin = await requireAdmin(request, env, data?.user);
        if (!admin) {
            return Response.json({ success: false, message: 'Unauthorized' }, { status: 401 });
        }

        const body = await request.json().catch(() => ({}));
        const username = typeof body.username === 'string' ? body.username.trim() : '';

        if (!username) {
            return Response.json({ success: false, message: '缺少使用者名稱' }, { status: 400 });
        }

        const target = await env.DB.prepare(
            "SELECT username, role FROM users WHERE username = ?"
        ).bind(username).first();

        if (!target) {
            return Response.json({ success: false, message: '找不到使用者' }, { status: 404 });
        }

        // Do not allow this endpoint to reset administrator accounts. Admin
        // password recovery should use a separate, audited break-glass flow.
        if (target.role === 'admin') {
            return Response.json({ success: false, message: '不能透過此端點重設管理員密碼' }, { status: 403 });
        }

        // Requested product behavior: reset to the fixed default password.
        // This remains protected by admin-only authorization above.
        const defaultPassword = '12345678';
        const newSalt = crypto.randomUUID();
        const newHash = await hashPassword(defaultPassword, newSalt);

        const result = await env.DB.prepare(
            "UPDATE users SET password = ?, salt = ?, session_token = NULL, token_created_at = NULL WHERE username = ?"
        ).bind(newHash, newSalt, username).run();

        if (!result.success) {
            return Response.json({ success: false, message: '密碼重設失敗' }, { status: 500 });
        }

        return Response.json({
            success: true,
            username,
            defaultPassword,
            message: '密碼已重設為預設密碼，請要求使用者登入後立即更改密碼'
        });
    } catch (error) {
        console.error('reset-password error:', error.message);
        return Response.json({ success: false, message: 'Internal Server Error' }, { status: 500 });
    }
}
